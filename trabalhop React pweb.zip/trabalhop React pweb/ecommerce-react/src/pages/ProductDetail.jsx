import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getProductById } from "../services/api";
import { useCart } from "../hooks/useCart";



function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const { addToCart } = useCart();


  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        setError("");
        const data = await getProductById(id);
        setProduct(data);
      } catch (err) {
  console.error("Erro ao carregar produtos:", err);
  setError("Não foi possível carregar produtos.");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [id]);

  if (loading) return <p style={{ padding: 16 }}>A carregar...</p>;
  if (error) return <p style={{ padding: 16 }}>{error}</p>;
  if (!product) return <p style={{ padding: 16 }}>Produto não encontrado.</p>;

  return (
    <div style={{ padding: 16 }}>
      <Link to="/">← Voltar</Link>

      <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: 16, marginTop: 12 }}>
        <div style={{ border: "1px solid #ddd", borderRadius: 12, padding: 12 }}>
          <img
            src={product.image}
            alt={product.title}
            style={{ width: "100%", height: 320, objectFit: "contain" }}
          />
        </div>

        <div>
          <h1 style={{ marginTop: 0 }}>{product.title}</h1>
          <p style={{ fontWeight: 700, fontSize: 20 }}>{product.price} €</p>
          <p>{product.description}</p>

          <button
  onClick={() => addToCart(product)}
  style={{ padding: "10px 14px", borderRadius: 10, border: "1px solid #ddd" }}
>
  Adicionar ao carrinho
</button>

        </div>
      </div>
    </div>
  );
}

export default ProductDetail;
