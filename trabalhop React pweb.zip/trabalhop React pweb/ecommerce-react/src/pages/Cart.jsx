import { Link } from "react-router-dom";
import CartItem from "../components/CartItem";
import { useCart } from "../hooks/useCart";

function Cart() {
  const { items, removeFromCart, setQty, subtotal, total } = useCart();

  if (items.length === 0) {
    return (
      <div style={{ padding: 16 }}>
        <h1>Carrinho</h1>
        <p>O carrinho está vazio.</p>
        <Link to="/">← Voltar à loja</Link>
      </div>
    );
  }

  return (
    <div style={{ padding: 16 }}>
      <h1>Carrinho</h1>

      {items.map((item) => (
        <CartItem
          key={item.id}
          item={item}
          onRemove={removeFromCart}
          onQtyChange={setQty}
        />
      ))}

      <hr />

      <p>Subtotal: <strong>{subtotal.toFixed(2)} €</strong></p>
      <p>Total: <strong>{total.toFixed(2)} €</strong></p>

      <Link to="/">← Continuar a comprar</Link>
    </div>
  );
}

export default Cart;
