import { useEffect, useMemo, useState } from "react";
import { CartContext } from "./CartContextCore";

const STORAGE_KEY = "cart_v1";

function readCart() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.error("Erro a ler carrinho:", err);
    return [];
  }
}

export function CartProvider({ children }) {
  const [items, setItems] = useState(() => readCart());

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch (err) {
      console.error("Erro a guardar carrinho:", err);
    }
  }, [items]);

  function addToCart(product) {
    setItems((prev) => {
      const existing = prev.find((i) => i.id === product.id);
      if (existing) {
        return prev.map((i) =>
          i.id === product.id ? { ...i, qty: i.qty + 1 } : i
        );
      }
      return [
        ...prev,
        {
          id: product.id,
          title: product.title,
          price: product.price,
          image: product.image,
          qty: 1,
        },
      ];
    });
  }

  function removeFromCart(id) {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  function setQty(id, qty) {
    const n = Number(qty);
    const safe = Number.isFinite(n) ? Math.max(1, n) : 1;
    setItems((prev) =>
      prev.map((i) => (i.id === id ? { ...i, qty: safe } : i))
    );
  }

  const subtotal = useMemo(
    () => items.reduce((sum, i) => sum + i.price * i.qty, 0),
    [items]
  );

  const total = subtotal;
  const count = useMemo(() => items.reduce((s, i) => s + i.qty, 0), [items]);

  const value = { items, addToCart, removeFromCart, setQty, subtotal, total, count };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
