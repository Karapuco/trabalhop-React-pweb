import { useContext } from "react";
import { CartContext } from "../context/CartContextCore";

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart tem de ser usado dentro de <CartProvider>");
  return ctx;
}
