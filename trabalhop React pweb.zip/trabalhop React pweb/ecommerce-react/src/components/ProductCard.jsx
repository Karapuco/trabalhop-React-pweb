import { Link } from "react-router-dom";

function ProductCard({ product }) {
  return (
    <Link
      to={`/product/${product.id}`}
      style={{
        textDecoration: "none",
        color: "inherit",
        border: "1px solid #ddd",
        borderRadius: 12,
        padding: 12,
        display: "block",
      }}
    >
      <div style={{ height: 180, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <img
          src={product.image}
          alt={product.title}
          style={{ maxHeight: "100%", maxWidth: "100%", objectFit: "contain" }}
        />
      </div>

      <h3 style={{ fontSize: 14, margin: "10px 0 6px" }}>{product.title}</h3>
      <p style={{ fontWeight: 700 }}>{product.price} €</p>
    </Link>
  );
}

export default ProductCard;
