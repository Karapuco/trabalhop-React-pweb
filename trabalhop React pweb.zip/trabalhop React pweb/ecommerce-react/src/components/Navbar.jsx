import { Link } from "react-router-dom";
import { useCart } from "../hooks/useCart";

function Navbar() {
  const { count } = useCart();

  return (
    <nav
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "12px 16px",
        borderBottom: "1px solid #ddd",
      }}
    >
      <Link to="/" style={{ textDecoration: "none", fontWeight: 700 }}>
        🛒 Loja Online
      </Link>

      <Link to="/cart" style={{ textDecoration: "none" }}>
        Carrinho ({count})
      </Link>
    </nav>
  );
}

export default Navbar;
