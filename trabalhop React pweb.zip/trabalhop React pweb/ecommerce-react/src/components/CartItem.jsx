function CartItem({ item, onRemove, onQtyChange }) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "80px 1fr 120px 80px",
        gap: 12,
        alignItems: "center",
        borderBottom: "1px solid #eee",
        padding: "12px 0",
      }}
    >
      <img
        src={item.image}
        alt={item.title}
        style={{ width: 80, height: 80, objectFit: "contain" }}
      />

      <div>
        <strong>{item.title}</strong>
        <div>{item.price} €</div>
      </div>

      <input
        type="number"
        min="1"
        value={item.qty}
        onChange={(e) => onQtyChange(item.id, e.target.value)}
        style={{ padding: 6 }}
      />

      <button onClick={() => onRemove(item.id)}>Remover</button>
    </div>
  );
}

export default CartItem;
